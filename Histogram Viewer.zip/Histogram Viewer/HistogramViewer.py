from re import L
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from numpy import loadtxt
import numpy.matlib
import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import filedialog as fd
from PIL import ImageTk, Image

def select_file():
    filetypes = (
        ('CSV', '*.csv'),
        ('All files', '*.*')
    )
    CMAP = 'inferno';
    LC = 'blue';
    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)
    [CH,RH,FH,EH,MD] = getCSVInfo(filename);
    plotData(CH,RH,FH,EH,MD,CMAP,LC);
    return CH,RH,FH,EH,MD;

def getCSVInfo(filename):
    filename = filename[0:len(filename)-7];

    #==============================================================================================================
    #Cyclic Histogram
    fileID = open(str(filename+'_CH.csv'), 'rb');
    CH = loadtxt(fileID,delimiter=",");
    CH = CH/np.max(CH,axis=0);

    #Residual Histogram
    fileID = open(str(filename+'_RH.csv'), 'rb');
    RH = loadtxt(fileID,delimiter=",");
    RH = RH/np.max(RH,axis=0);

    #Frequency Histogram
    fileID = open(str(filename+'_FH.csv'), 'rb');
    FH = loadtxt(fileID,delimiter=",");

    #Energy Histogram
    fileID = open(str(filename+'_EH.csv'), 'rb');
    EH = loadtxt(fileID,delimiter=",");

    #Meta Data
    metaData = open(str(filename+'_MD.csv'),'r');

    for line in metaData:
        x = line;
        x = x[0:len(x)-1];
        y = x.split(',');
        try:
            globals()[y[0].replace(" ", "_")] = np.asarray(y[1]).astype(np.float32);
        except:
            globals()[y[0].replace(" ", "_")] = y[1];

    MD = (
        'DFR Name: ' + DFR_Name + '\n' +
        'Line: ' + str(Channel_Name) + ', ' + str(Channel_Phase) + ', ' + str(Channel_Line_Name) + '\n' +
        'Signal Collection Date: ' + str(Record_Date) + '\n' + 
        'Signal Collection Time: [' + str(int(Start_Hour)) + ':00 - ' + str(int(End_Hour)) + ':00]\n' +
        'Time Zone: ' + str(Time_Zone) + '\n' +
        'Nominal Voltage Range: [' + str(np.round(Cycles_Min.astype('float32')/1000,decimals=2)) + ',' + str(np.round(Cycles_Max.astype('float32')/1000,decimals=2)) + '] kV')

    #==============================================================================================================
    #Residual Histogram
    
    MD = (MD + '\nResidual Voltage Range: [' + str(np.round(Residual_Min.astype('float32')/1000,decimals=2)) + ',' + str(np.round(Residual_Max.astype('float32')/1000,decimals=2)) + '] kV');

    #==============================================================================================================
    #Frequency Histogram

    binLin = np.linspace(Frequency_Min.astype('float32'),Frequency_Max.astype('float32'),FH.shape[0]);
    MD = (MD + '\nAverage Frequency: ' + str(np.round(np.sum(np.dot(FH,binLin)),decimals=3)) + 'Hz');
    del binLin

    #==============================================================================================================
    #RMS Histogram

    binLin = np.linspace(RMS_Min.astype('float32'),RMS_Max.astype('float32'),EH.shape[0])/1000;

    MD = (MD + '\nAverage RMS Value: ' + str(np.round(np.sum(np.dot(EH,binLin)),decimals=3)) + ' kV');
    del binLin

    return CH,RH,FH,EH,MD;

def plotData(CH,RH,FH,EH,MD,CMAP,LC):
    #Cyclic Histogram
    channelName = DFR_Name;
    tStart = Start_Hour.astype('int');
    tEnd = End_Hour.astype('int');
    extent = 0, 16, Cycles_Min.astype('float32')/1000, Cycles_Max.astype('float32')/1000;

    plt.style.use('dark_background');
    fig = plt.gcf()
    plt.clf()
    ax1 = plt.subplot(231)
    plt.imshow(CH,aspect='auto', extent=extent, cmap=CMAP);
    plt.xlabel('Sample');
    plt.ylabel('Voltage (kV)');
    plt.title('Cyclic Histogram');

    #Residual Histogram
    channelName = DFR_Name;
    tStart = Start_Hour.astype('float32');
    tEnd = End_Hour.astype('float32');
    extent = 0, 16, Residual_Min.astype('float32')/1000, Residual_Max.astype('float32')/1000;

    ax2 = plt.subplot(232)
    plt.imshow(RH,aspect='auto', extent=extent, cmap=CMAP);
    plt.xlabel('Sample');
    plt.ylabel('Voltage (kV)');
    plt.title('Residual Histogram');

    #Frequency Histogram
    channelName = DFR_Name;
    freqMin = Frequency_Min.astype('float32');
    freqMax = Frequency_Max.astype('float32');
    binLin = np.linspace(freqMin,freqMax,FH.shape[0]);

    ax3 = plt.subplot(234)
    plt.vlines(60-0.02,ymin=0,ymax=np.max(FH),colors='yellow',linestyle='--');
    plt.vlines(60+0.02,ymin=0,ymax=np.max(FH),colors='yellow',linestyle='--');
    plt.plot(binLin,FH,color=LC);
    plt.xlabel('Frequency (Hz)');
    plt.title('Frequency Histogram');
    plt.grid(True,color='0.2')

    #RMS Energy
    channelName = DFR_Name;
    rmsMin = RMS_Min.astype('float32');
    rmsMax = RMS_Max.astype('float32');
    binLin = np.linspace(rmsMin,rmsMax,EH.shape[0]);

    ax4 = plt.subplot(235);
    plt.plot(binLin,EH,color=LC);
    plt.xlabel('RMS (kV)');
    plt.title('RMS Histogram');
    plt.grid(True,color='0.2');
    props = dict(boxstyle='round', facecolor='black', alpha=0.5)
    ax4.text(2,1,MD, transform=ax4.transAxes, fontsize=18, ha='center', va='center', bbox=props);

    fig.suptitle(str(channelName+' ['+str(int(tStart))+':00 - '+str(int(tEnd))+':00]'), fontsize=20);

    plt.show()

# create the root window
root = tk.Tk()
root.title('Power Histogram Viewer')
root.resizable(False, False)
root.geometry('876x400')
root.configure(background='black')

canvas = Canvas(root, width = 874, height=299);
canvas.pack();
im = ImageTk.PhotoImage(Image.open('histogram view logo.jpg'));
canvas.create_image(437,150,anchor=CENTER,image=im);

CMAP = 'inferno';
LC = 'blue'

#graph_button=Button(root,text="Generate graph",command=Graph_Generator)
#graph_button.pack(pady=30)
#root.mainloop()

# open button
open_button = ttk.Button(
    root,
    text='Open Histogram Data',
    command=select_file
)

open_button.pack(expand=True)

# run the application
root.mainloop()