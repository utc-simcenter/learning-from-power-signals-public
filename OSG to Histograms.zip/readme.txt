#================================================================================================================
Copyright 2021 University of Tennessee/University of Tennessee Research Foundation

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#================================================================================================================
CONTRIBUTORS:
Joshua H. Tyler
Donald R. Reising, Ph.D.; donald-reising@utc.edu; 423-425-5843
#================================================================================================================
INSTRUCTIONS FOR RUNNING:
The application is located in /dist/OSGtoHistograms/OSGtoHistograms.exe
The settings with the file locations are stored in /dist/OSGtoHistograms/settings.txt

#Version 2.4b (BETA)
#================================================================================================================
#Changelog

#V1.0.1
#1. RAM optimization when loading in channel data.
#2. Changed target OSG to be newest file in folder instead of from CFG file.
#3. FFT optimizations
#V1.0.2b (BETA)
#1. Converted input files to float32 to reduce RAM usage
#2. Changed file to process a single hour at a time to reduce RAM usage
#3. Changed the default window step in the FFT to match the window size to reduce FFT histogram time
#4. Changed default process bandwidth to 0.2 to increase resolution of the area of interest in the FFT histogram.
#5. Added bus channel phase to the filename

#V1.0.2b2 (BETA)
#1. Added support for an accompanying settings.txt file for CFG, OSG, and Data file management

#V1.0.3b (BETA)
#1. Changed file naming scheme for [.cfg Filename] + [Hour] + [Bus Name] + [Bus Phase] + [Histogram Type]
#2. Significant decrease in FFT compute time

#V1.1b (BETA)
#1. Added RMS histograms (EH + EH_MD)
#2. Added additional medadata to include time-zone, line number, and the signal collection date
#3. Moved all user-set variables to be read from the settings.txt file

#V1.1.1b (BETA)
#1. Changed file naming scheme to [DFR Name] + [Hour] + [Bus Name] + [Bus Phase] + [Histogram Type]
#2. Changed OSG file search to use the current date found v.i.a. datetime
#3. Reduced output CSV filesize by changing '000000000000e+00' to '0'

#V1.1.2b (BETA)
#1. Changed file naming scheme to [DFR Name] + [Hour] + [Bus Name] + [Bus Phase] + [Histogram Type]
#2. Fixed hour/OSG filename selector flags

#V1.1.3b (BETA)
#1. Added debug flag that states what task is being run and its process time.

#V2.1b (BETA)
#1. Changed metadata to be stored as one file per channel per hour.
#2. Changed metadata to include total cycles captured and data percision.
#2. Added potential for parallel FFT processing on future multi-core systems.

#v2.3 (BETA)
#1. Included an RMS threshold to bypass process channels with no activity.

#v2.4 (BETA)
#1. General bug fixes. No new functionality.

#=========================================
Readme file for OSGtoHistograms.py
Written by:
Joshua Tyler
Electrical Engineering
University of Tennessee at Chattanooga
Aug 30, 2021

#Version 1.0.1
#================================================================================================================
#Changelog

#V1.0.1
#1. RAM optimization when loading in channel data.
#2. Changed target OSG to be newest file in folder instead of from CFG file.
#3. Added an override option to target custom OSG filenames.
#4. FFT optimizations

#=========================================
PURPOSE
Use Histograms to consolidate data from IEEE OSG files into managable CSV Files

ACTIONS:
1. Searches for the most recent CFG file in the same folder as the "OSGtoHistograms.py" file.
2. Searches for analog line data for all voltage lines in the OSG file and pulls:
	a) Channel Index
	b) Channel Name
	c) Channel Multiples (To convert from int16 to float64)
	d) Transformer Side (Either Secondary or Primary)
	c) Transformer Turn Ratio (To convert to Primary if the DAQ is on the Secondary side)
3. Uses the record start date to determine the OSG filename to read.
4. Converts the signal data to floats and primary bus side representation
5. Time-syncs the signal to line up consistently on the ideal time stamps for the cycle.
	t = [0:SPC]/Fsamp
6. Calculates the cyclic histogram with the bin limits being global to the entire cycle's behavior.
7. Calculates the residual histogram by subtracting the first cycle from the rest of the calculated cycles with the bin limits being global to the entire cycle's behavior.
9. Calculates a custom Fourier transform only over the fundamental frequency plus and minus half of a specified bandwidth. The dominant frequency is returned.
10. Calculates the histogram from the dominant frequency across a recording.
11. Saves these 3 histograms per evaluation time per channel under the file names:
	a) 'cyclicHistogram_' + Channel Name + '_hour_' + Evaluated Hour + '_' DFR Name + '_' + OSG Filemane + '.csv'
	b) 'residualHistogram_' + Channel Name + '_hour_' + Evaluated Hour + '_' DFR Name + '_' + OSG Filemane + '.csv'
	c) 'frequencyHistogram_' + Channel Name + '_hour_' + Evaluated Hour + '_' DFR Name + '_' + OSG Filemane + '.csv'
A metadata file is saved which holds the bus name, start hour, and bin limits. These associated metadata files have '_metadata' appended to the end of the filename of the histogram they represent.

Approximate time for processing is 5-10 minutes per channel. Total filesize should be around:
	a) 450Kb per cyclic histogram.
	b) 450Kb per residual histogram
	c) 10Kb per frequency histogram
	d) 1MB total per evaluation
For 3 lines with 1 hour per evaluation, the total resultant data taken up will approximately be 72MB, around 1/7 of the space taken by a line's continuous waveform data.

#=========================================
SYSTEM REQUIREMENTS
CPU: Quad-Core Intel or AMD
RAM: 8Gb Minimum, 16Gb Reccomended
OS: Windows 10
GPU: None
Internet: None

#=========================================
PYTHON REQUIREMENTS:
- Python 3.7 (Available in the Windows Store)
- Numpy (Version 1.21.1)
- Numba (Version 0.53.1)

To run the program, the python script "OSGtoHistograms.py" must be in the same folders as the CFG and OSG file to be processed.
#=========================================
CFG File Assumptions:
- All CFG files are set in IEEE Comtrade 2013 Standard
- The target CFG is the newest .CFG file in the folder

#=========================================
OSG File Assumptions:
- ALL OSG files are set in IEEE Comtrade 2013 Standard
- The target OSG is represented by the newest .CFG file in the folder
- 24 Hours of Analog Data is stored interweaved at the begning of the OSG file, followed by the digital channel data.
	Where for N channels of L length, the OSG file is organized as: C_{0}[0],C_{1}[0],C_{2}[0],...,C_{N}[0],...,C_{N}[L-1],C_{N}[L]
- The Default sampling rate is 960hz, with a fundamental frequency of 60Hz, and therefore sampled at 16 samples per cycle
- The total samples per signal should be 82944000

#=========================================
User-Changable Variables:
- "histBins": Number of bins to use for the cyclic and residual histograms. Default is 1024 bins.
- "hoursPerHistogram": Sets the number of hours per histogram. This needs to be an interger divisor of 24, (i.e. [1,2,4,6,8,12,24]). Default is 1.
- "SPCoverride": Binary decision to override the samples per second. If 1, the samples per second will be overridden with the "SPCoverrideValue" variable. If 0, the samples per second will be determined by dividing the sampling rate by the fundamental frequency found in the CFG file. Default is 1.
- "SPCoverrideValue": Sets the value to overide the samples per second from the CFG file. Default is 16.
-"searchLines": Determines the string to search for in column 2 in the analog line data in the CFG file. Default is ["Va","Vb","Vc"].
-"searchTypes": determines the string to search for in column 5 in the analog line data in the CFG file. Default is ["V","kV"].
- "FsamplesPerFFT": Determines the number of samples over which to calculate the Fourier Transform for the frequency histogram. This is also the number of bins for the support of the frequency histogram. Default is 256.
- "cyclesPerFFT": Determines the number of cycles per frequency content evaluation. Default is 60.
- "cycleStepsPerFFT": Determines the number of cycles to step by in the next frequency content evaluation. Default is 30.
- "PBW": Acronym for 'Process Bandwdith', determines the limits of the frequency of which to calculate the Fourier Transform, and the limits bounds of the support of the frequency histogram. This bandwidth wraps the fundamental frequency. Default value is 10.
- "OSGfromCFG": Decides if the target OSG filename will be found from the CFG file, or as the newest created file in the directory. Defualt is set to 0.
- "OSGfileOverride": Allows the user to override the script-determined OSG filename with a user input. Default is set to 0.
- "OSGfilenameOverride": User-input (string) do override the script-determined OSG filename. Sorted by yyyy/mm/dd, (e.x. a target for March 21, 2021 will be 20210321).