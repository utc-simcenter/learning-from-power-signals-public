#================================================================================================================
#DISCLAIMER: THIS IS A BETA RELEASE AND NOT INTENDED FOR DEPLOYMENT. DEPLOYMENT OF THIS VERSION IS STRONGLY DISCOURAGED AND THE AUTHORS CLAIM NO RESPONSIBILITY FOR ISSUES CAUSED BY USING THIS SOFTWARE.

#Copyright 2021 University of Tennessee/University of Tennessee Research Foundation

#Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
#1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
#2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
#3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

#THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
#PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
#LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
#TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#================================================================================================================
#CONTRIBUTORS:
#Joshua H. Tylerm M.S.; joshua-tyler@mocs.utc.edu;
#Donald R. Reising, Ph.D.; donald-reising@utc.edu; 423-425-5843
#================================================================================================================

from tkinter import Y
import numpy as np
import numba
from numba import jit
import os.path;
import glob, os
import time
import re
from datetime import datetime
from datetime import timedelta
from timeit import default_timer as timer

print("Running 'OSG to Cyclic Histogram' code version 2.5 (BETA)");

#Version 2.4b (BETA)
#================================================================================================================
#Changelog

#V1.0.1
#1. RAM optimization when loading in channel data.
#2. Changed target OSG to be newest file in folder instead of from CFG file.
#3. FFT optimizations
#V1.0.2b (BETA)
#1. Converted input files to float32 to reduce RAM usage
#2. Changed file to process a single hour at a time to reduce RAM usage
#3. Changed the default window step in the FFT to match the window size to reduce FFT histogram time
#4. Changed default process bandwidth to 0.2 to increase resolution of the area of interest in the FFT histogram.
#5. Added bus channel phase to the filename

#V1.0.2b2 (BETA)
#1. Added support for an accompanying settings.txt file for CFG, OSG, and Data file management

#V1.0.3b (BETA)
#1. Changed file naming scheme for [.cfg Filename] + [Hour] + [Bus Name] + [Bus Phase] + [Histogram Type]
#2. Significant decrease in FFT compute time

#V1.1b (BETA)
#1. Added RMS histograms (EH + EH_MD)
#2. Added additional medadata to include time-zone, line number, and the signal collection date
#3. Moved all user-set variables to be read from the settings.txt file

#V1.1.1b (BETA)
#1. Changed file naming scheme to [DFR Name] + [Hour] + [Bus Name] + [Bus Phase] + [Histogram Type]
#2. Changed OSG file search to use the current date found v.i.a. datetime
#3. Reduced output CSV filesize by changing '000000000000e+00' to '0'

#V1.1.2b (BETA)
#1. Changed file naming scheme to [DFR Name] + [Hour] + [Bus Name] + [Bus Phase] + [Histogram Type]
#2. Fixed hour/OSG filename selector flags

#V1.1.3b (BETA)
#1. Added debug flag that states what task is being run and its process time.

#V2.1b (BETA)
#1. Changed metadata to be stored as one file per channel per hour.
#2. Changed metadata to include total cycles captured and data percision.
#2. Added potential for parallel FFT processing on future multi-core systems.

#v2.2 (BETA)
#1. Included an RMS threshold to bypass process channels with no activity.

#2.4 (BETA)
#1. Changed residual histogram to subtract ideal sinusoid instead of first captured cycle
#2. Added feature to assume ideal peak-to-peak value using voltage stated in channel name
#3. Fixed cycle interpolation algorithm
#4. Added option to process all 24 hours of the selected histogram
#5. Increased flaot32 time and frequency vector percision
#6. Added check to skip histogram calculation if zero cycles are detected

#================================================================================================================
#Define Non-Jit Accellerated Functions
def isInt(value):
    try:
        int(value)
        return True
    except ValueError:
        return False

def isLineType(busName,searchLines):
    check = 0;
    for i in range(len(searchLines)):
        if (busName==searchLines[i]):
            check = 1;
            break
    if (check==1):
        return True
    else:
        return False
        
def prepStrSave(x,sigDig):
    y = np.empty(x.shape).tolist();
    for i in range(x.shape[0]):
        try:
            for j in range(x.shape[1]):
                temp = str(x[i,j]);
                if temp == '0.0':
                    y[i][j] = '0';
                else:
                    y[i][j] = temp[0:sigDig];
                    for k in range(len(temp)):
                        if temp[k] == 'e':
                            y[i][j] = str(y[i][j] + temp[k:len(temp)]);
        except:
            temp = str(x[i]);
            if temp == '0.0':
                y[i] = '0';
            else:
                y[i] = temp[0:sigDig];
                for k in range(len(temp)):
                    if temp[k] == 'e':
                        y[i] = str(y[i] + temp[k:len(temp)]);
    return y;

def s2hms(y3):
    y3 = int(y3);
    y = "";
    if (y3 == 0):
        y1 = 0;
    else:
        y1 = np.floor(y3/(60*60)).astype("int");
        
    y3 = y3 - y1*60*60;
    y = y + "{:02d}".format(y1);
    
    if (y3 == 0):
        y2 = 0;
    else:
        y2 = np.floor(y3/60).astype("int");
    y3 = y3 - (y2*60);
    y = y + "{:02d}".format(y2);
    y = y + "{:02d}".format(y3);
    return y;

def getPeak(x):
    mult = 1;
    for i in range(len(x)-1):
        y = x[0:i+1];
        try:
            y = int(y);
        except:
            if y[len(y)-1] == "k":
                mult = 1000;
            elif y[len(y)-1] == "M":
                mult = 1000000;
            y = int(x[0:i])*mult;
            break;
    return y*np.sqrt(2)/np.sqrt(3);
#================================================================================================================
#Define NUMBA accelerated functions

#Generate a linspace
@jit(nopython=True,cache=True)
def jitLinspace(x0,x1,N):
    y = np.arange(N);
    y = y/2;
    dx = (x1-x0)/(N-1);
    for i in range(N):
        y[i] = x0 + dx*i;
    y = y.astype('float32');
    return y

#Generate twiddle
@jit(nopython=True,fastmath=True,cache=True)
def getTwiddle(freq,t):
    y = np.zeros((len(freq),len(t)),dtype='complex64');
    for i in range(len(freq)):
        y[i,0:len(t)] = np.exp(1j*2*np.pi*freq[i]*t);

    return y;

#Calculate RMS for entire waveform
@jit(nopython=True,fastmath=True,cache=True)
def getRMS(x):
    y = np.sqrt(np.var(x));
    #y = np.sqrt(np.sum(np.power(x,2))/len(x));
    return y;

#Calculate instantaneous frequency and RMS values across the recording
@jit(nopython=True,fastmath=True,cache=True)
def getFreq(x,f,samplesPerCycle,cyclesPerEval,cycleSteps,freq):
    totalCycles = len(x)/samplesPerCycle;
    evaluations = int(1+(totalCycles-cyclesPerEval)/cycleSteps);
    lineFreq = np.zeros(evaluations,dtype='float32');
    lineFreq = lineFreq/2;

    lineRMS = np.zeros(evaluations,dtype='float32');
    lineRMS = lineRMS/2;

    for i in range(evaluations):
        xArray = x[i*cycleSteps*samplesPerCycle:i*cycleSteps*samplesPerCycle+cyclesPerEval*samplesPerCycle];
        #lineRMS[i] = np.sqrt(np.sum(np.power(xArray,2))/len(xArray));
        lineRMS[i] = np.sqrt(np.var(xArray));

        #This section is for serial FFT processing, faster
        xSpec = np.arange(freq.shape[0]);
        xSpec.astype('float32');
        for j in range(freq.shape[0]):
            xSpec[j] = np.absolute(np.sum(xArray*freq[j,0:freq.shape[1]]));
        lineFreq[i] = f[np.argmax(xSpec)];

        #This section is for parallel FFT processing, slower
        #lineFreq[i] = f[np.argmax(np.absolute(np.sum(freq*xArray,axis=1)))];

    return lineFreq, lineRMS

#Time Sync Signal for Cyclic Histogram
@jit(nopython=True,fastmath=True,cache=True)
def getCycles(signal,tIdeal,SPC,idealCycles,cycles):
    Tsamp = tIdeal[1]-tIdeal[0];
    Ffund = 1/(Tsamp*SPC);
    j = 0;
    while (j < idealCycles):
        if (j == 0):
            check = 0;
            k = 0;
            while (check == 0):
                if ((signal[k] < 0 and signal[k+1] > 0) or signal[k]==0):
                    startSample = k;
                    check = 1;
                k=k+1;
        doInterp = 1;
        k = startSample+SPC-3;
        check = 0;
        while (check == 0):
            if ((signal[k] < 0 and signal[k+1] > 0) or (signal[k] == 0 and signal[k-1]<0 and signal[k+1] >0)):
                signalTemp = signal[startSample:k+2];
                startSample = k;
                check = 1;
            k=k+1;
            if (signal[startSample]==0 and signal[k] ==0):
                doInterp=0;
            
            if (k-startSample) > int(SPC + SPC/2):
                k = startSample+k;
                startSample = k;
                doInterp = 0;
            if k+SPC > len(signal):
                break;
        if (doInterp == 1):
            dt1 = 0;
            dt2 = 0;
            m1 = (signalTemp[1]-signalTemp[0])/Tsamp;
            if (m1==0):
                dt1 == 0;
            else:
                dt1 = signalTemp[0]/m1;

            m2 = (signalTemp[len(signalTemp)-1]-signalTemp[len(signalTemp)-2])/Tsamp;
            if (m2==0):
                dt2 = 0;
            else:
                dt2 = signalTemp[len(signalTemp)-1]/m2;

            tTempStart = dt1;
            tTempStop = tIdeal[len(tIdeal)-1] + dt2;
            tTempStep = (tTempStop-tTempStart)/len(signalTemp);
            tTemp = np.arange(start=0,stop=int(len(signalTemp)),step=1);
            tTemp = tTemp/2;
            for l in range(int(len(tTemp))):
                tTemp[l] = tTempStart + tTempStep*l;
            signalNew = np.interp(tIdeal,tTemp,signalTemp)
            cycles[j,0:SPC] = signalNew[0:SPC];
            j = j+1;

        if (doInterp ==0):
            if (startSample+SPC)<len(signal):
                cycles[j,0:SPC] = signal[startSample:startSample+SPC];
                j = j+1;
        if k+SPC > len(signal):
            break;
    totalCycles = j+1;
    cycles = cycles[0:totalCycles+1,0:SPC];
    return cycles, totalCycles;

#Generate Cyclic Histograms
@jit(nopython=True,cache=True)
def getCyclicHistogram(cycles,histBins,binMin,binMax,cyclicHistogram):
    for j in range(SPC+1):
        tempHist = np.histogram(cycles[0:totalCycles,j],bins=histBins,range=(binMin,binMax));
        cyclicHistogram[0:histBins,j] = np.flip(np.transpose(tempHist[0]/np.sum(tempHist[0])));
    return cyclicHistogram

@jit(nopython=True,cache=True)
def getFreqHistogram(lineFreq,histBins,binMin,binMax):
    freqHistogram = np.histogram(lineFreq,bins=histBins,range=(binMin,binMax));
    freqHistogram = np.transpose(freqHistogram[0]/np.sum(freqHistogram[0]));
    return freqHistogram

#================================================================================================================
#Read the Settings File to locate the CFG, OSG, and data folder
locationSettings = open('../../settings.txt','r');
for x in locationSettings:
    line = x;
    variable = '';
    for i in range(len(line)):
        if line[i]== ' ':
            break;
        else:
            variable = variable + str(line[i]);
    i = i+1;
    startReading = 0;
    value = '';
    for j in range(len(line)-i):
        if line[j+i] == ';':
            break;
        if startReading == 1:
            value = value+str(line[j+i]);
        if line[j+i] == ' ':
            startReading = 1;

    skipValuePlacement = 0;
    if len(variable) > 6:
        readLine = 0;
        if variable[0:6] == 'search':
            valueTemp = '';
            for i in range(len(value)):
                if value[i] != "'" and value[i] != '[' and value[i] != ']':
                    valueTemp = valueTemp + value[i];
            globals()[variable] = valueTemp.split(',');
            del valueTemp
            skipValuePlacement = 1;

    if skipValuePlacement == 0:
        try:
           value = float(value);
           if value == int(value):
               value = int(value);
           globals()[variable] = value;
        except:
            globals()[variable] = value;
    del line, variable, value, i, startReading

#================================================================================================================
#Check the data file (.csv output) directory and create it if it does not exist
if not os.path.exists(datLoc):
    os.makedirs(datLoc);

#================================================================================================================
#Read Latest Config File to Pull Channel Data and OSG Filename
if useCustomCFG == 1:
    cfgLoc = "../../";

configType = '*,F*.cfg';
os.chdir(cfgLoc);
files = glob.glob(configType);
CFGfilename = max(files, key=os.path.getctime);
print('Found target CFG file: ' + CFGfilename);
f = open(CFGfilename,'r');

tempdata = CFGfilename.split(",");
timezone = tempdata[2];
devicename = tempdata[3];
devicemanufacturer = tempdata[4];
deviceowner = tempdata[5];

del tempdata;

CFGfilename = CFGfilename[0:len(CFGfilename)-4]
numChannels = 0;
i = 0;
c = 0;
totalLines = 12;
dataType = {
    'names' : ('Channel Number','Channel Name','Channel Phase','Channel Multiple','Channel Side','Ratio','Line Name'),
    'formats': ('i','|U64','|U12','d','|U12','d','|U12')}

for x in f:
    line = x;
    line = line.split(",");
    if (i==0):
        DFRname = line[0];
        IEEEstandard = int(line[2]);
    if (i==1):
        totalLines = int(line[0]);
        analogLines = line[1];
        k = 0;
        for j in analogLines:
            if isInt(j):
                k = k+1;
        analogLines = int(analogLines[0:k]);
        digitalLines = line[2];
        k = 0;
        for j in digitalLines:
            if isInt(j):
                k = k+1;
        digitalLines = int(digitalLines[0:k]);
        channelData = np.zeros(analogLines,dataType);
    if ((i>1)&(i<totalLines+2)):
        chanNum = line[0];
        chanName = line[1];
        busName = line[2];
        busType = line[4];
        if (isLineType(busType,searchTypes)&(isLineType(busName,searchLines))):
            channelData['Channel Number'][c] = int(line[0]);
            channelData['Channel Name'][c] = line[3];
            channelData['Channel Phase'][c] = line[2];
            channelData['Channel Multiple'][c] = line[5];
            channelData['Channel Side'][c] = line[12];
            channelData['Ratio'][c] = np.double(line[10])/np.double(line[11]);
            channelData['Line Name'][c] = line[1];
            c = c+1;
    if (i==totalLines+2):
        Ffund = int(np.double(line[0]));
    if (i==totalLines+4):
        Fsamp = int(np.double(line[0]));
    if (i==totalLines+6):
        recordDate = line[0];
    i = i+1;

channelData = channelData[:][0:c];
useChannels = channelData['Channel Number'][:];
print('CFG Channel Metadata:');
print(channelData);

#Find the number of samples per cycle
SPC = int(Fsamp/Ffund);
if SPCoverride == 1:
    SPC = SPCoverrideValue;
    Fsamp = Ffund*SPC;
Tsamp = 1/(Ffund*SPC);

samplesPerEvaluation = (hoursPerHistogram*60*60 + minutesPerHistogram*60 + secondsPerHistogram)*SPC*60;

today = datetime.now();

if (processAllHours == 0):
    if startHourFromDatetime == 1: #Process one hour based on the current datetime hour
        processHour = int(today.strftime("%H")) - 1;
        if processHour == -1:
            today = today - timedelta(days=1);
            processHour = 23;
        startSample = (processHour)*60*60*Fsamp;
        numberOfHistograms = np.floor(60*60*SPC*60/samplesPerEvaluation).astype("int64");
    else: #Process one hour based on the user-set hour
        startSample = (startHour*60*60 + startMinute*60 + startSecond) * SPC * 60;
    
    processHour = np.array([startHour,0]).astype("int64");
else: #Process all hours based on the user-set hour
    processHour = np.arange(start=0,stop=25).astype("int64");
    numberOfHistograms = np.floor(60*60*SPC*60/samplesPerEvaluation).astype("int64");
    
    startSample = 0;

if (samplesPerEvaluation < 16*cyclesPerFFT):
    cyclesPerFFT = np.floor(samplesPerEvaluation/SPC).astype("int64");
    cycleStepsPerFFT = np.floor(samplesPerEvaluation/(SPC*2)).astype("int64");

tIdeal = np.arange(start=0,stop=(1/Ffund)+2*Tsamp,step=Tsamp);

#================================================================================================================
#================================================================================================================
#Automated Script

if OSGfromDatetime==1:
    OSGfilename = str("20"+today.strftime("%y%m%d")+".osg");
else:
    configType = '*.osg';
    files = glob.glob(configType);
    OSGfilename = max(files, key=os.path.getctime);

if OSGfileOverride==1:
    OSGfilename = str(str(OSGfilenameOverride)+".osg");

os.chdir(osgLoc);
inputFile = open(osgLoc + OSGfilename,'rb');
data = np.fromfile(inputFile,dtype=np.int16,count=2);
print('Found target OSG File: '+OSGfilename);

recordDate = str(OSGfilename[4:6]) + '/' + str(OSGfilename[6:8]) + '/' + str(OSGfilename[0:4]);

OSGfilename = OSGfilename[0:len(OSGfilename)-4];
if not os.path.exists(datLoc+OSGfilename):
    os.makedirs(datLoc+OSGfilename);

cyclesPerHistogram = Ffund*60*60;

#Get twiddle factor for custom FFT
freq = np.linspace(start=Ffund-PBW/2,stop=Ffund+PBW/2,num=FsamplesPerFFT);
t = np.arange(start=0,stop=Tsamp*(cyclesPerFFT*SPC),step=Tsamp);

freq_compile = getTwiddle(freq,t);

for i in range(len(processHour)-1):
    for j in range(numberOfHistograms):
        print("==========================================");
        startTime = s2hms(startSample/(SPC*60));
        endTime = s2hms((startSample + samplesPerEvaluation)/(SPC*60));
        print('Processing Signals for ' + startTime[0:2] + ':' + startTime[2:4] + ':' + startTime[4:6] + ' to ' + endTime[0:2] + ':' + endTime[2:4] + ':' + endTime[4:6]);
        
        #================================================================================================================
        #================================================================================================================
        #Start data processing
        inputFile.seek(2*(analogLines*startSample+2));
        data = np.fromfile(inputFile,dtype=np.int16,count=(analogLines*samplesPerEvaluation));

        if (debug==1):
            print("Loading channel data...");
        channelSignals = np.zeros([len(useChannels),samplesPerEvaluation],dtype=processDataType);
        for k in range(len(useChannels)):
            channelSignals[k,0:samplesPerEvaluation] = data[np.arange(start=useChannels[k]-1,stop=useChannels[k]-1+(samplesPerEvaluation*analogLines),step=analogLines)]*channelData['Channel Multiple'][k];
            if channelData['Channel Side'][k] == 'S':
                channelSignals[k,0:samplesPerEvaluation] = channelSignals[k,0:samplesPerEvaluation]*channelData['Ratio'][k];
        
        del data

        if (debug==1):
            print("Channel data successfully loaded.");

        metaDataArray = np.empty([23,2],dtype='object');
        metaDataArray[0,0] = 'DFR Name';
        metaDataArray[1,0] = 'Channel Name';
        metaDataArray[2,0] = 'Channel Phase';
        metaDataArray[3,0] = 'Channel Line Name';
        metaDataArray[4,0] = 'Fundamental Frequency';
        metaDataArray[5,0] = 'Sampling Rate';
        metaDataArray[6,0] = 'Start Time';
        metaDataArray[7,0] = 'End Time';
        metaDataArray[8,0] = 'Total Captured Cycles';
        metaDataArray[9,0] = 'Cycles Max';
        metaDataArray[10,0] = 'Cycles Min';
        metaDataArray[11,0] = 'Residual Max';
        metaDataArray[12,0] = 'Residual Min';
        metaDataArray[13,0] = 'Frequency Max';
        metaDataArray[14,0] = 'Frequency Min';
        metaDataArray[15,0] = 'RMS Max';
        metaDataArray[16,0] = 'RMS Min';
        metaDataArray[17,0] = 'Cyclic Histogram Bins';
        metaDataArray[18,0] = 'Residual Histogram Bins';
        metaDataArray[19,0] = 'Frequency Histogram Bins';
        metaDataArray[20,0] = 'Data Percision';
        metaDataArray[21,0] = 'Record Date';
        metaDataArray[22,0] = 'Time Zone';

        metaDataArray[0,1] = DFRname;
        metaDataArray[4,1] = Ffund;
        metaDataArray[5,1] = Fsamp;
        metaDataArray[6,1] = startTime[0:2] + ":" + startTime[2:4] + ":" + startTime[4:6];
        metaDataArray[7,1] = endTime[0:2] + ":" + endTime[2:4] + ":" + endTime[4:6];
        metaDataArray[13,1] = str(Ffund+PBW/2);
        metaDataArray[14,1] = str(Ffund-PBW/2);
        metaDataArray[17,1] = histBins;
        metaDataArray[19,1] = FsamplesPerFFT;
        metaDataArray[20,1] = savePercision;
        metaDataArray[21,1] = str(OSGfilename[4:6] + '/' + OSGfilename[6:8] + '/' + OSGfilename[0:4]);
        metaDataArray[22,1] = timezone;

        for k in range(len(useChannels)):
            if (debug==1):
                print("=============================================");
            
            
            print('Working on ' + str(channelData['Channel Name'][k]) + ' ' + str(channelData['Channel Phase'][k]) + ' (Channel ' + str(k+1) + "/" + str(len(useChannels)) + ')');
            if (getRMS(channelSignals[k,0:samplesPerEvaluation]) > rmsThreshold):
                saveFilename = str(OSGfilename + ',' + startTime + ',' + endTime + ',' + timezone + ',' + devicename + ',' + devicemanufacturer + ',' + deviceowner + ',' + channelData['Line Name'][k] + ',' + channelData['Channel Name'][k] + ',' + channelData['Channel Phase'][k]);
                idealCycles = int(samplesPerEvaluation/SPC-1);

                metaDataArray[1,1] = str(channelData['Channel Name'][k]);
                metaDataArray[2,1] = str(channelData['Channel Phase'][k]);
                metaDataArray[3,1] = str(channelData['Line Name'][k]);

                idealCycle = getPeak(metaDataArray[1,1])*np.sin(2*np.pi*Ffund*t[0:SPC]);

                #print('Capturing Cycles')
                if (debug==1):
                    print("Capturing cycle data...");
                    tStart = datetime.now()
                cycles = np.zeros([idealCycles,SPC],dtype='float32');
                [cycles,totalCycles] = getCycles(channelSignals[k,0:samplesPerEvaluation],tIdeal,SPC,idealCycles,cycles);
                if totalCycles > 2:
                    cycles = cycles[0:totalCycles-1,0:SPC+1];

                    if (debug==1):
                        tEnd = datetime.now()
                        print("Successfully captured cycle data with " + str(totalCycles) + " cycles (" + str(np.round((tEnd-tStart).total_seconds()*1000,2)) + "ms)");
    
                    if saveCycles == 1:
                        np.savetxt(datLoc+'/'+str(OSGfilename+'/'+CFGfilename+'_'+startTime+'_'+endTime+'_'+saveFilename+'_cycles.csv'),cycles,delimiter=",");

                    #Calculate and Save Cyclic and Residual Histogram
                    cyclicHistogram = np.zeros([histBins,SPC+1]);

                    if (debug==1):
                        print("Calculating cyclic histogram...");
                        tStart = datetime.now()
                    cyclicHistogram = getCyclicHistogram(cycles,histBins,np.amin(cycles),np.amax(cycles),cyclicHistogram);
                    if (debug==1):
                        tEnd = datetime.now()
                        print("Successfully calculated cyclic histogram (" + str(np.round((tEnd-tStart).total_seconds()*1000,2)) + "ms)");
                    
                    metaDataArray[8,1] = str(totalCycles);
                    metaDataArray[9,1] = str(np.amax(cycles));
                    metaDataArray[10,1] = str(np.amin(cycles));

                    #print('Processing Residual Histogram')
                    cycles = idealCycle.transpose() - cycles;
                    
                    residualMax = np.amax(np.abs([np.amax(cycles),np.amin(cycles)]));
                    if (residualMax < 5000):
                        residualMax = 5000;
                        residualMin = -5000;
                        residualBins = histBins;
                    elif ((residualMax<10000)and(residualMax>5000)):
                        residualMax = 10000;
                        residualMin = -10000;
                        residualBins = histBins*2;
                    elif ((residualMax<20000)and(residualMax>1000)):
                        residualMax = 20000;
                        residualMin = -20000;
                        residualBins = histBins*4;
                    else:
                        residualMax = 50000;
                        residualMin = -50000;
                        residualBins = histBins*4;

                    residualHistogram = np.zeros([residualBins,SPC+1]);
                    
                    metaDataArray[11,1] = str(residualMax);
                    metaDataArray[12,1] = str(residualMin);
                    metaDataArray[18,1] = residualBins;
                    
                    if (debug==1):
                        print("Calculating residual histogram...");
                        tStart = datetime.now()
                    residualHistogram = getCyclicHistogram(cycles,residualBins,residualMin,residualMax,residualHistogram);
                    if (debug==1):
                        tEnd = datetime.now()
                        print("Successfully calculated resudial histogram (" + str(np.round((tEnd-tStart).total_seconds()*1000,2)) + "ms)");
                    
                    

                    del cycles;

                    #Calculate and Save Frequency Histogram
                    if (debug==1):
                        print("Calculating frequency and RMS data...");
                        tStart = datetime.now()
                    [lineFreq,lineRMS] = getFreq(channelSignals[k,0:samplesPerEvaluation],freq,SPC,cyclesPerFFT,cycleStepsPerFFT,freq_compile);
                    if (debug==1):
                        tEnd = datetime.now()
                        print("Successfully calculated frequency and RMS data (" + str(np.round((tEnd-tStart).total_seconds()*1000,2)) + "ms)");
                        print("Calculating frequency Histogram...");
                        tStart = datetime.now()
                    freqHistogram = getFreqHistogram(lineFreq,FsamplesPerFFT,Ffund-PBW/2,Ffund+PBW/2);
                    if (debug==1):
                        tEnd = datetime.now()
                        print("Successfully calculated frequency histogram (" + str(np.round((tEnd-tStart).total_seconds()*1000,2)) + "ms)");
                    
                    del lineFreq;

                    #Calculate and Save RMS Histogram
                    if (debug==1):
                        print("Calculating RMS Histogram...");
                        tStart = datetime.now()
                    rmsMin = np.min(lineRMS);
                    rmsMax = np.max(lineRMS);

                    if (rmsMin==rmsMax):
                        rmsMin = rmsMin - 0.01*rmsMin;
                        rmsMax = rmsMax + 0.01*rmsMax;

                    rmsHistogram = getFreqHistogram(lineRMS,FsamplesPerFFT,rmsMin,rmsMax);
                    if (debug==1):
                        tEnd = datetime.now()
                        print("Successfully calculated RMS histogram (" + str(np.round((tEnd-tStart).total_seconds()*1000,2)) + "ms)");
                    
                    metaDataArray[15,1] = str(rmsMax);
                    metaDataArray[16,1] = str(rmsMin);
                    
                    np.savetxt(datLoc+'/'+str(OSGfilename+'/'+saveFilename+',MD.csv'),metaDataArray,delimiter=",",fmt='%s');

                    if (saveCSV == 1):
                        np.savetxt(datLoc+'/'+str(OSGfilename+'/'+saveFilename+',CH.csv'),prepStrSave(cyclicHistogram,saveSignificantDigits),delimiter=",",fmt='%s');
                        np.savetxt(datLoc+'/'+str(OSGfilename+'/'+saveFilename+',RH.csv'),prepStrSave(residualHistogram,saveSignificantDigits),delimiter=",",fmt='%s');
                        np.savetxt(datLoc+'/'+str(OSGfilename+'/'+saveFilename+',FH.csv'),prepStrSave(freqHistogram,saveSignificantDigits),delimiter=",",fmt='%s');
                        np.savetxt(datLoc+'/'+str(OSGfilename+'/'+saveFilename+',EH.csv'),prepStrSave(rmsHistogram,saveSignificantDigits),delimiter=",",fmt='%s');
                        
                    if (saveBinary == 1):
                        savearray = cyclicHistogram.reshape([(SPC+1)*histBins,1]);
                        savearray = np.concatenate([savearray,residualHistogram.reshape([(SPC+1)*residualBins,1])],0);
                        savearray = np.concatenate([savearray,freqHistogram.reshape([FsamplesPerFFT,1])],0);
                        savearray = np.concatenate([savearray,rmsHistogram.reshape([FsamplesPerFFT,1])],0);
                        savefile = open(datLoc+'/'+OSGfilename+'/'+str(saveFilename+'.bin'),'w');
                        savearray.astype(savePercision).tofile(savefile);
                else:
                    print("No detected");
            else:
                print("RMS threshold of " + str(rmsThreshold) + " not met.");
        startSample = startSample + samplesPerEvaluation;
        del channelSignals;

print('done');